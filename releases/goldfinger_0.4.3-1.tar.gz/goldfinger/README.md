# goldfinger

R package to facilitate safe sharing of data using encryption

To install this package from our drat repository, try the following:

```r
options(
  repos = structure(c(CRAN="https://cran.rstudio.com/",
          "ku-awdc"="https://ku-awdc.github.io/drat/"))
)
install.packages("goldfinger")
```

Or you can check out the instructions at:

https://www.costmodds.org/rsc/teaching/setup_guide.html
