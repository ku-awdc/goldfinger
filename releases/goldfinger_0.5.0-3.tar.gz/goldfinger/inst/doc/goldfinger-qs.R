## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----eval=FALSE---------------------------------------------------------------
# install.packages(c("Rcpp", "RApiSerialize", "RcppParallel", "stringfish", "BH"))

## ----eval=FALSE---------------------------------------------------------------
# install.packages("https://cran.r-project.org/src/contrib/Archive/stringfish/stringfish_0.16.0.tar.gz", repos = NULL)

## ----eval=FALSE---------------------------------------------------------------
# install.packages("https://cran.r-project.org/src/contrib/Archive/qs/qs_0.27.3.tar.gz", repos = NULL)

## ----eval=FALSE---------------------------------------------------------------
# options(
#   repos = structure(c(CRAN="https://cran.rstudio.com/",
#           "ku-awdc"="https://ku-awdc.github.io/drat/"))
# )
# install.packages("goldfinger")

## ----eval=FALSE---------------------------------------------------------------
# gy_resave("data_file.rdg")

