#' @name gy_serialise
#' @title Serialise and deserialise a list of objects/files
#' @param object
#' @param file
#' @param user
#' @param local_user
#' @param ascii
#' @param version
#' @param compress
#' @param overwrite
#'
#' @rdname gy_serialise
#' @export
gy_serialise <- function(object, files=character(0), method="base", ...){

  if(!is.character(method) || length(method)!=1 || is.na(method)) stop("The serialisation method argument must be a length 1 character", call.=FALSE)

  if(any(names(object)==".serialise_files")){
    stop("The name '.serialise_files' is reserved - please rename this element of the object list", call.=FALSE)
  }

  ## TODO: files
  if(length(files)>0) stop("Serialising files is not yet implemented")

  mtch <- pmatch(method, serialization_options)
  if(is.na(mtch)) stop(str_c("Unrecognised serialisation method argument '", method, "' - options are: ", str_c(serialization_options, collapse=", ")))
  method <- serialization_options[mtch]

  if(method == "base"){
    # base::serialize, which does not allow compression:
    rv <- serialize(object=object, connection=NULL, ...)
  }else if(method == "qs"){
    stop("Serialisation using qs is no longer supported", call.=FALSE)
    # qs::qserialize, with or without compression (default with):
    # rv <- qserialize(x=object, ...)
  }else if(method == "custom"){
    stop("The custom serialisation method is invalid for this function", call.=FALSE)
  }else{
    stop("Serialisation method '", method, "' is not yet implemented - perhaps update the package?", call.=FALSE)
  }

  ## Add the serialization method and versions as attributes:
  attr(rv, "ser_method") <- method
  attr(rv, "versions") <- get_versions(type="deserialise")

  return(rv)
}


#' @rdname gy_serialise
#' @export
gy_deserialise <- function(object, files=TRUE, ...){

  if(!is.raw(object)) stop("The provided object must be of type raw", call.=FALSE)

  method <- attr(object, "ser_method", exact=TRUE)
  if(is.null(method)){
    warning("The provided object did not have a serialization method attribute - assuming that this is base::serialize")
    method <- "base"
  }

  versions <- attr(object, "versions", exact=TRUE)
  if(is.null(versions)) stop("The versions attribute is missing")
  check_version(versions)

  if(!is.character(method) || length(method)!=1 || is.na(method)) stop("The serialisation method attribute must be a length 1 character", call.=FALSE)
  if(method=="serialise") method <- "serialize"

  mtch <- pmatch(method, serialization_options)
  if(is.na(mtch)) stop(str_c("Unrecognised serialisation method attribute '", method, "' - options are: ", str_c(serialization_options, collapse=", ")))
  method <- serialization_options[mtch]

  if(method == "base"){
    # base::unserialize
    rv <- unserialize(connection=object, ...)
  }else if(method == "qs"){
    if(!requireNamespace("qs")){
      if(getRversion() >= "4.6"){
        stop('
 The qs package is required to deserialise the saved object within this encrypted file.
 Unfortunately, qs cannot be installed on R version 4.6.0 or later - this means that you
 will have to downgrade to R version 4.5.x to read this file. See the vignette for more
 details on how to install the qs package and convert your existing saved files to a
 future-proof format:
 vignette("goldfinger-qs")
')
      }else{
        stop('
 The qs package is required to deserialise the saved object within this encrypted file.
 See the vignette for more details on how to install the qs package and convert your
 existing saved files to a future-proof format:
 vignette("goldfinger-qs")
')
      }
    }
    if(package_env$qs_warning) warning('Using qs to deserialise will break after R 4.5.x - see:  vignette("goldfinger-qs")')
    rv <- qs::qdeserialize(x=object, ...)
  }else if(method == "custom"){
    stop("Unable to automatically deserialise custom-serialised objects", call.=FALSE)
  }else{
    stop("Deserialisation method '", method, "' is not yet implemented - perhaps update the package?", call.=FALSE)
  }

  return(rv)

}

# Common to both functions:
serialization_options <- c("custom", "base", "qs")

#' @rdname gy_serialise
#' @export
gy_serialize <- gy_serialise

#' @rdname gy_serialise
#' @export
gy_deserialize <- gy_deserialise
