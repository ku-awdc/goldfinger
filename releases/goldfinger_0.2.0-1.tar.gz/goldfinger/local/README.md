This folder is for any file that you don't want to leave your computer.  The entire folder (except for this file) is on the gitignore list.
