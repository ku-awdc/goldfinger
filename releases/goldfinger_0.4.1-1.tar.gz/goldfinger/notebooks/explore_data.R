library("goldfinger")

(load("D:/Goldfinger/CHRdata/CHR_DB_20210504.Rdata"))

kaelvning

object.size(omsaetning)

omsaetning

Koder_omsaetning

