library(testthat)
library(goldfinger)

test_check("goldfinger")
